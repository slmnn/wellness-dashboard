<?php

$_POST[ "echoed" ] = true;
echo json_encode( $_POST );
