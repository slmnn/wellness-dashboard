<?php sleep( 5 ); ?>
{ "delayed": "request" }