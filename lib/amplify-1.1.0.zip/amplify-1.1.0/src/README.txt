For the latest version of AmplifyJS source code, please visit http://amplifyjs.com.

This source was packaged as v1.1.0 on 2011-11-08 11:52:28

